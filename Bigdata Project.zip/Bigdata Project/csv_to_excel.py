from pyspark.sql import SparkSession
import pandas as pd

# Initialize Spark session
spark = SparkSession.builder.appName("CSV to Excel").getOrCreate()

# Define HDFS paths
hdfs_input_path = "/user/cdanovbdh03487/Bigdata/use.csv"
local_output_path = "/user/cdanovbdh03487/BigData/data.xlsx"

# Read CSV file from HDFS
df = spark.read.csv(hdfs_input_path, header=True, inferSchema=True)

# Convert Spark DataFrame to Pandas DataFrame
pandas_df = df.toPandas()

# Save Pandas DataFrame to Excel
pandas_df.to_excel(local_output_path, index=False)

# Stop the Spark session
spark.stop()